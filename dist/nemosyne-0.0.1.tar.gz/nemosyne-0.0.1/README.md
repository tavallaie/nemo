nemosyne (aka [Mnemosyne](https://en.wikipedia.org/wiki/Mnemosyne)) is an S3 command-line manager.
